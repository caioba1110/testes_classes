package aula02;

public interface Diagonal{
   default double diagonal(double altura){
      return altura * Math.sqrt(2);
   }
}