package aula02;

public class Quadrado extends Poligono implements Diagonal{
   public Quadrado(double base, double altura){
      setBase(base);
      setAltura(altura);
   }
   public double perimetro(){
      return getBase() * getBase() * getBase() * getBase();
   }
}