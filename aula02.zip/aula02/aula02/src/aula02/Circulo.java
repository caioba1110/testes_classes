package aula02;

public class Circulo extends Figura{

   private double raio;
   
   public Circulo(double r){
      raio = r;
   }
   
   public void setRaio(double raio){
      this.raio = raio;
   }
   public double getRaio(){
      return raio;
   }
   @Override
   public double area(){
      return Math.PI * raio * raio;
   }
   public double perimetro(){
      return Math.PI * 2 * raio;
   }
}