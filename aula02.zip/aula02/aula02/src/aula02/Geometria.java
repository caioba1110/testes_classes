package aula02;

import java.util.ArrayList;
public class Geometria{
   public Figura figura;
   ArrayList<Figura> array = new ArrayList<Figura>();
   public void incluir(Figura fig){
      array.add(fig);
   }
   public void print(){
      for (Figura figura : array){
         System.out.println("Area:");
         System.out.println(figura.area());
         System.out.println("Perimetro:");
         System.out.println(figura.perimetro());
      }
   }
}