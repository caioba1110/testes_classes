package aula02;

public class Teste{
   public static void main(String args []){
      Geometria geo = new Geometria();
      Triangulo trian = new Triangulo(10, 15);
      Losango losan = new Losango(10, 15);
      Retangulo retan = new Retangulo(10, 15);
      Quadrado quadra = new Quadrado(10, 15);
      Circulo circu = new Circulo(15);
      
      geo.incluir(trian);
      geo.incluir(losan);
      geo.incluir(retan);
      geo.incluir(quadra);
      geo.incluir(circu);
      
      geo.print();
   }
}