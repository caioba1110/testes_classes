package aula02;

public class Losango extends Poligono{
   public Losango(double base, double altura){
      setBase(base);
      setAltura(altura);
   }
   public double perimetro(){
      return getBase() * getBase() * getBase() * getBase();
   }
   public double area() {
	   return super.area() / 2;
   }
}