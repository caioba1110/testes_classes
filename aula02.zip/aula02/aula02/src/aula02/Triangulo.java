package aula02;

public class Triangulo extends Poligono{
   
   public Triangulo(double base, double altura){
      setBase(base);
      setAltura(altura);
   }
   @Override
   public double area(){
      return (getBase() * getAltura()) / 2;
   }
   public double perimetro(){
      return getBase() * getBase() * getBase();
   }
}