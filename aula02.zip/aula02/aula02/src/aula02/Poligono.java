package aula02;

public abstract class Poligono extends Figura{
   private double base;
   private double altura;
   
   public void setBase(double base){
      this.base = base;
   }
   public void setAltura(double altura){
      this.altura = altura;
   }
   
   public double getBase(){
      return base;
   }
   public double getAltura(){
      return altura;
   }
   
   public double area(){
      return (base * altura);
   }
   
   //public abstract double perimetro();
   
} 