package aula02;

public class Retangulo extends Poligono implements Diagonal{
   public Retangulo(double base, double altura){
      setBase(base);
      setAltura(altura);
   }
   public double perimetro(){
      return getBase() * getBase() * getAltura() * getAltura();
   }
}